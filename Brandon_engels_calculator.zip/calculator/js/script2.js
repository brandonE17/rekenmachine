function getnumbers(value){
  
  let display= document.getElementById("display").value +=value;
  console.log(display);
  

}
function answer(value){

let display= document.getElementById("display");
display.value = eval(display.value);
console.log(display);



}
function cleardisplay(){

  document.getElementById("display").value=""
}
  