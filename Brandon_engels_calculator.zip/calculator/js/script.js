function getnumbers(value){
  
  let display= document.getElementById("display").value +=value;
  console.log(display);
  

}
function answer(value){

let display= document.getElementById("display").value +=value;
console.log(display);


}
function times(value){

let display= document.getElementById("display").value +=value;
console.log(display);

}
 